﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oblig4_O3
{
    internal class Bil
    {
        //Datamedlem
        private string biltype;
        private string eier;
        private string skilt;

        //Tilgangsmedlem
        public string BilType
        {
            get { return biltype; }
            set { biltype = value; }
        }
        public string Eier
        {
            get { return eier; }
            set { eier = value; }
        }
        public string Skilt
        {
            get { return skilt; }
            set { skilt = value; }
        }


        public Bil(string bil_type,  string eier_navn, string skilt_nummer)
        {
            BilType = bil_type;
            Eier = eier_navn;
            Skilt = skilt_nummer;
        }

        public override string ToString()
        {
            return $"Biltype: {biltype}, Eier av bilen: {eier}, Skiltnummer: {skilt}";
        }


    }
}

﻿using System.Runtime.InteropServices;

namespace Oblig4_O3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Bil> biler = new List<Bil>();
            List<String> Skiltbokstaver = new List<String>();
            Random rnd = new Random();
            int lengstenavn = 0;
            int Skiltnummer1 = 0;
            int Skiltnummer2 = 0;
            int Skiltnummer3 = 0;
            int Skiltnummer4 = 0;
            int Skiltnummer5 = 0;
            String alfabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            String random = "";
            int bokstav1 = 0;
            int bokstav2 = 0;
            string[] biltyper = { "Ford", "Kia", "Mazda", "Ferrari", "Lamborghini", "Mclaren", "Mitsubitshi", "Toyota" };
            int biltype = 0;
            string[] fornnavn = { "Anna", "Anne", "Marie", "Ingrid", "Ole", "Hans", "Arne", "Jan" };
            string[] etternavn = { "Hansen", "Johansen", "Olsen", "Larsen", "Pettersen", "Andersen", "Haugen", "Johannessen"};
            int navnfor = 0;
            int navnetter = 0;
            for (int i = 0; i < 10; i++)
            {
                Skiltnummer1 = rnd.Next(0, 9);
                Skiltnummer2 = rnd.Next(0, 9);
                Skiltnummer3 = rnd.Next(0, 9);
                Skiltnummer4 = rnd.Next(0, 9);
                Skiltnummer5 = rnd.Next(0, 9);
                bokstav1 = rnd.Next(26);
                bokstav2 = rnd.Next(26);
                biltype = rnd.Next(8);
                navnfor = rnd.Next(8);
                navnetter = rnd.Next(8);
                Bil b = new Bil(biltyper.ElementAt(biltype), fornnavn.ElementAt(navnfor) + " " + etternavn.ElementAt(navnetter), random + 
                    alfabet.ElementAt(bokstav1) + random + alfabet.ElementAt(bokstav2) +
                    Skiltnummer1 + Skiltnummer2 + Skiltnummer3 + Skiltnummer4 + Skiltnummer5);
                biler.Add(b);
            }
            biler = biler.OrderBy(bil => bil.Skilt).ToList();
            foreach (Bil b in biler)
            {
                Console.WriteLine(b.ToString());
            }
            lengstenavn = biler.Max(bil => bil.Eier.Length);
            var eiereMedLengsteNavn = biler.Where(bil => bil.Eier.Length == lengstenavn).Select(bil => bil.Eier).Distinct();
            Console.WriteLine("\nEiere med lengste navn:");
            foreach (var eier in eiereMedLengsteNavn)
            {
                Console.WriteLine(eier);
            }

        }
    }
}
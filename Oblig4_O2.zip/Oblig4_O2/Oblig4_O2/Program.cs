﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        Random rnd = new Random();
        List<int> randomNumbers = new List<int>();

        for (int i = 0; i < 100000; i++)
        {
            int randomNumber = rnd.Next(-1000000, 1000001);
            randomNumbers.Add(randomNumber);
        }

        HashSet<int> absoluttverdier = new HashSet<int>();

        foreach (int number in randomNumbers)
        {
            int absoluteValue = Math.Abs(number);
            absoluttverdier.Add(absoluteValue);
        }

        int count = absoluttverdier.Count;

        Console.WriteLine("Antall verdier som er like hverandre ved absoluttverdi: " + count);
    }
}
